import Card from "./Card";

function  Section() {
    const employees=[
        {
            id: 1,
            name: "Deepika",
            phn: "7207634155",
            branch: "AIML"
        },
        {
            id: 2,
            name: "Harika",
            phn: "1234567890",
            branch: "CSE"
        },
        {
            id: 3,
            name: "Sai",
            phn: "9876543210",
            branch: "ECE"
        }
    ]
return (
    <section>
        {
            employees.map((emp)=>(

                <Card
                id={emp.id}
                name={emp.name}
                phn={emp.phn}
                branch={emp.branch}
                />
            ))
        }

    </section>
);
}
export  default Section;