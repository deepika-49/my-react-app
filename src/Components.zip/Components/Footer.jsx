function Footer() {
    return (
        <footer>
            <p>Footer Area</p>
        </footer>
    );
}

export default Footer;