function Card(props){
    return(
        <>
        <style>
            {
                `
                .Card{
                    width: 300px;
                    background-color: white;
                    border: 2px solid blue;
                    border-radius: 15px;
                    padding: 20px;
                    margin: 20px auto;
                    box-shadow: 0px 4px 10px(0,0,0,0.2);
                    transition: 0.3s;
                    font-family: Arial, sans-serif;
                }

                .Card:hover{
                    transform: scale(1.03);
                }

                .Card h3{
                    margin-bottom: 15px;
                    text-align: center;
                }

                .Card p{
                    font-size: 16px;
                    margin: 8px 0;
                }
                `
            }
        </style>
        <div className="Card">
            <h3>name:{props.name}</h3>
            <p>id:{props.id}</p>
            <p>phone Number:{props.phone}</p>
            <p>branch:{props.branch}</p>
        </div>
        </>
    );
}
export default Card;